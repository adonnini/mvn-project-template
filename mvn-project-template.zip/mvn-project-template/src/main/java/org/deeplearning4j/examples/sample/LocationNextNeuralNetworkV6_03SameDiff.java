/* *****************************************************************************
 *
 *
 *
 * This program and the accompanying materials are made available under the
 * terms of the Apache License, Version 2.0 which is available at
 * https://www.apache.org/licenses/LICENSE-2.0.
 *  See the NOTICE file distributed with this work for additional
 *  information regarding copyright ownership.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 *
 * SPDX-License-Identifier: Apache-2.0
 ******************************************************************************/

package org.deeplearning4j.examples.sample;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.math3.stat.StatUtils;
import org.datavec.api.records.reader.SequenceRecordReader;
import org.datavec.api.records.reader.impl.csv.CSVSequenceRecordReader;
import org.datavec.api.split.NumberedFileInputSplit;
import org.deeplearning4j.core.storage.StatsStorage;
import org.deeplearning4j.datasets.datavec.SequenceRecordReaderDataSetIterator;
import org.deeplearning4j.ui.api.UIServer;
import org.deeplearning4j.ui.model.storage.InMemoryStatsStorage;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RefineryUtilities;
import org.nd4j.autodiff.listeners.impl.ScoreListener;
import org.nd4j.autodiff.listeners.records.History;
import org.nd4j.autodiff.samediff.SDVariable;
import org.nd4j.autodiff.samediff.SameDiff;
import org.nd4j.autodiff.samediff.TrainingConfig;
import org.nd4j.common.primitives.Pair;
import org.nd4j.evaluation.classification.Evaluation;
import org.nd4j.linalg.api.buffer.DataType;
import org.nd4j.linalg.api.ndarray.INDArray;
import org.nd4j.linalg.api.ops.impl.layers.recurrent.config.LSTMActivations;
import org.nd4j.linalg.api.ops.impl.layers.recurrent.config.LSTMDataFormat;
import org.nd4j.linalg.api.ops.impl.layers.recurrent.config.LSTMDirectionMode;
import org.nd4j.linalg.api.ops.impl.layers.recurrent.config.LSTMLayerConfig;
import org.nd4j.linalg.api.ops.impl.layers.recurrent.outputs.LSTMLayerOutputs;
import org.nd4j.linalg.api.ops.impl.layers.recurrent.weights.LSTMLayerWeights;
import org.nd4j.linalg.dataset.DataSet;
import org.nd4j.linalg.dataset.api.iterator.DataSetIterator;
import org.nd4j.linalg.dataset.api.preprocessor.NormalizerStandardize;
import org.nd4j.linalg.factory.Nd4j;
import org.nd4j.linalg.learning.config.Adam;
import org.nd4j.weightinit.impl.XavierInitScheme;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.swing.*;
import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

@SuppressWarnings("ResultOfMethodCallIgnored")
public class LocationNextNeuralNetworkV6_03SameDiff {
    private static final Logger Log = LoggerFactory.getLogger(LocationNextNeuralNetworkV6_03SameDiff.class);

    //'baseDir': Base directory for the data. Change this if you want to save the data somewhere else
    private static File baseDir = new File("src/main/resources/uci/");
    private static File baseTrainDir = new File(baseDir, "train");
    private static File featuresDirTrain = new File(baseTrainDir, "features");
    private static File labelsDirTrain = new File(baseTrainDir, "labels");
    private static File baseTestDir = new File(baseDir, "test");
    private static File featuresDirTest = new File(baseTestDir, "features");
    private static File labelsDirTest = new File(baseTestDir, "labels");

    private static int contentAndLabels2Size = 0;
//    private static int contentAndLabelsSize = 0;

    private static int nItemsInDataSet = contentAndLabels2Size;   //75% train, 25% test
    //    private static int nItemsInDataSet = contentAndLabelsSize;   //75% train, 25% test
    private static int nTrain = (int)Math.round(nItemsInDataSet * .75);

    private static int nTest = nItemsInDataSet - nTrain;

    private static int lastTrainCount = 0;
    private static int lastTestCount = 0;

    private static SequenceRecordReader trainFeatures;
    private static SequenceRecordReader trainLabels;
    private static DataSetIterator trainData;
    private static SequenceRecordReader testFeatures;
    private static SequenceRecordReader testLabels;
    private static DataSetIterator testData;
    private static NormalizerStandardize normalizer;

    //Properties for dataset:
    private static int nIn = 6;
    private static int nOut = 2;

    private static int miniBatchSize = 32;
    private static int numLabelClasses = -1;

    private static SameDiff sd = SameDiff.create();

    private static long dim0 = 0L;
    private static long  dim1 = 0L;
    private static long dim2 = 0L;

    private static DataSet t;

    public static void main(String[] args) throws Exception {

        downloadUCIData();

        System.out.println("nTrain - "+nTrain);
        System.out.println("nTest - "+nTest);
        System.out.println("lastTrainCount - "+lastTrainCount);
        System.out.println("lastTestCount - "+lastTestCount);

        Log.info("Log.info test --- ");

        Nd4j.getExecutioner().enableVerboseMode(true);
        Nd4j.getExecutioner().enableDebugMode(true);

        sameDiff3();

    }

    public static void sameDiff3() throws IOException, InterruptedException
    {

        // ----- Load the training data -----
        trainFeatures = new CSVSequenceRecordReader();
        trainFeatures.initialize(new NumberedFileInputSplit(featuresDirTrain.getAbsolutePath() + "/%d.csv", 0, lastTrainCount));
        trainLabels = new CSVSequenceRecordReader();
        trainLabels.initialize(new NumberedFileInputSplit(labelsDirTrain.getAbsolutePath() + "/%d.csv", 0, lastTrainCount));

        trainData = new SequenceRecordReaderDataSetIterator(trainFeatures, trainLabels, miniBatchSize, numLabelClasses,
                true, SequenceRecordReaderDataSetIterator.AlignmentMode.ALIGN_END);


        // ----- Load the test data -----
        //Same process as for the training data.
        testFeatures = new CSVSequenceRecordReader();
        testFeatures.initialize(new NumberedFileInputSplit(featuresDirTest.getAbsolutePath() + "/%d.csv", 0, lastTestCount));
        testLabels = new CSVSequenceRecordReader();
        testLabels.initialize(new NumberedFileInputSplit(labelsDirTest.getAbsolutePath() + "/%d.csv", 0, lastTestCount));

        testData = new SequenceRecordReaderDataSetIterator(testFeatures, testLabels, miniBatchSize, numLabelClasses,
                true, SequenceRecordReaderDataSetIterator.AlignmentMode.ALIGN_END);

        normalizer = new NormalizerStandardize();
        normalizer.fitLabel(true);
        normalizer.fit(trainData);           //Collect the statistics (mean/stdev) from the training data. This does not modify the input data
        trainData.reset();

        while(trainData.hasNext()) {
            normalizer.transform(trainData.next());     //Apply normalization to the training data
        }

        while(testData.hasNext()) {
            normalizer.transform(testData.next());         //Apply normalization to the test data. This is using statistics calculated from the *training* set
        }

        trainData.reset();
        testData.reset();

        trainData.setPreProcessor(normalizer);
        testData.setPreProcessor(normalizer);

        System.out.println(" Printing traindata dataset shape - 1");
        DataSet data = trainData.next();
        System.out.println(Arrays.toString(data.getFeatures().shape()));

        System.out.println(" Printing testdata dataset shape - 1");
        DataSet data2 = testData.next();
        System.out.println(Arrays.toString(data2.getFeatures().shape()));

        trainData.reset();
        testData.reset();

        //ADD VISUALIZATION CODE HERE - START - <*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*>
        //Initialize the user interface backend
        UIServer uiServer = UIServer.getInstance();

        //Configure where the network information (gradients, score vs. time etc) is to be stored. Here: store in memory.
        StatsStorage statsStorage = new InMemoryStatsStorage();         //Alternative: new FileStatsStorage(File), for saving and loading later

        //Attach the StatsStorage instance to the UI: this allows the contents of the StatsStorage to be visualized
        uiServer.attach(statsStorage);

        //Then add the StatsListener to collect this information from the network, as it trains
        int listenerFrequency = 1;
        sd.setListeners(new ScoreListener());
//        sd.setListeners( new StatsListener(statsStorage, listenerFrequency));
//        restored.setListeners(new StatsListener(statsStorage, listenerFrequency));
        //ADD VISUALIZATION CODE HERE - END - <*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*><*>

        t = trainData.next();
        dim0 = t.getFeatures().size(0);
        dim1 = t.getFeatures().size(1);
        dim2 = t.getFeatures().size(2);
        System.out.println(" features - dim0 - 0 - "+dim0);
        System.out.println(" features - dim1 - 0 - "+dim1);
        System.out.println(" features - dim2 - 0 - "+dim2);
        trainData.reset();

        getConfiguration();

        int whileLoopIndex = 0;
        Map<String,INDArray> placeholderData = new HashMap<>();

        whileLoopIndex = -1;
        trainData.reset();
        while(trainData.hasNext()) {
            ++whileLoopIndex;
            placeholderData = new HashMap<>();
            t = trainData.next();

            INDArray features = t.getFeatures();
            INDArray labels = t.getLabels();
            placeholderData.put("input", features);
            placeholderData.put("label", labels);

            dim0 = t.getFeatures().size(0);
            dim1 = t.getFeatures().size(1);
            dim2 = t.getFeatures().size(2);

//            //Perform training for 2 epochs
//            int numEpochs = 2;
//            sd.fit(trainData, numEpochs);

            History history = sd.fit(t);

            System.out.println(" Completed training run --- ");

        }

        System.out.println(" Starting test data evaluation --- ");

        //Evaluate on test set:
        String outputVariable = "out";
        Evaluation evaluation = new Evaluation();
        sd.evaluate(testData, outputVariable, evaluation);

        //Print evaluation statistics:
        System.out.println(" evaluation.stats() - "+evaluation.stats());


        String pathToSavedNetwork = "src/main/assets/location_next_neural_network_v6_07.zip";
        File savedNetwork = new File(pathToSavedNetwork);

        sd.save(savedNetwork, true);
//        ModelSerializer.addNormalizerToModel(savedNetwork, normalizer);

        System.out.println("----- Example Complete -----");

        //Save the trained network for inference - FlatBuffers format
        File saveFileForInference = new File("src/main/assets/sameDiffExampleInference.fb");

        try {
            sd.asFlatFile(saveFileForInference);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    private static void getConfiguration()
    {

        //Create input and label variables
        SDVariable input = sd.placeHolder("input", DataType.FLOAT, dim0, dim1, dim2);
        SDVariable label = sd.placeHolder("label", DataType.FLOAT, miniBatchSize, nOut, t.getLabels().size(2));

        //Define LSTM layer

        LSTMLayerConfig mLSTMConfiguration = LSTMLayerConfig.builder()
                .lstmdataformat(LSTMDataFormat.NTS)
                .directionMode(LSTMDirectionMode.BIDIR_CONCAT)
                .gateAct(LSTMActivations.SIGMOID)
                .cellAct(LSTMActivations.SOFTPLUS)
                .outAct(LSTMActivations.SOFTPLUS)
                .retFullSequence(true)
                .retLastC(false)
                .retLastH(false)
                .build();

        LSTMLayerOutputs outputs = new LSTMLayerOutputs(sd.rnn.lstmLayer(
                input,
                LSTMLayerWeights.builder()
                        .weights(sd.var("weights", Nd4j.rand(DataType.FLOAT, 2, dim2, 4 * nOut)))
                        .rWeights(sd.var("rWeights", Nd4j.rand(DataType.FLOAT, 2, nOut, 4 * nOut)))
                        .bias(sd.var("bias", Nd4j.rand(DataType.FLOAT, 2, 4 * nOut)))
                        .build(),
                mLSTMConfiguration), mLSTMConfiguration);

        SDVariable layer0 = outputs.getOutput();

//            SDVariable layer1 = layer0.mean(1);

        System.out.println(" input.getShape()[0] - "+input.getShape()[0]);
        System.out.println(" input.getShape()[1] - "+input.getShape()[1]);
        System.out.println(" input.getShape()[2] - "+input.getShape()[2]);

        SDVariable w1 = sd.var("w1", new XavierInitScheme('c', nIn, nOut), DataType.FLOAT, miniBatchSize, 4, input.getShape()[2]);
        SDVariable b1 = sd.var("b1", Nd4j.rand(DataType.FLOAT, 1));

        SDVariable out = sd.nn.softmax("out", layer0.mmul(w1).add(b1));

        SDVariable loss = sd.loss.logLoss("loss", label, out);

        sd.setLossVariables("loss");

        //Create and set the training configuration
        double learningRate = 1e-3;
        TrainingConfig config = new TrainingConfig.Builder()
                .l2(1e-4)                               //L2 regularization
                .updater(new Adam(learningRate))        //Adam optimizer with specified learning rate
                .dataSetFeatureMapping("input")         //DataSet features array should be associated with variable "input"
                .dataSetLabelMapping("label")           //DataSet label array should be associated with variable "label"
                .build();

        sd.setTrainingConfig(config);

        System.out.println(" Printing sd information");
        System.out.println(sd.summary());

    }


    //This method downloads the data, and converts the "one time series per line" format into a suitable
    //CSV sequence format that DataVec (CsvSequenceRecordReader) and DL4J can read.
    private static void downloadUCIData() throws Exception {
        if (baseDir.exists()) return;    //Data already exists, don't download it again

        String gpsTrackPointsFilePath = "src/main/assets/neuralNetworkDataSet.csv";

        InputStream myInput2 = null;
        myInput2 = new FileInputStream(gpsTrackPointsFilePath);

        File myFile = new File(gpsTrackPointsFilePath);

        Path myPath = myFile.toPath();

        List<String[]> recordsDateTimeChangedToDouble2 = new ArrayList<String[]>();

        recordsDateTimeChangedToDouble2 = readLineByLine2(myPath);

        String pathToFileWithDateTimeChangedToDouble = "src/main/assets/go_track_trackspoints_modified-3.csv";
        String pathToFileWithDateTimeChangedToDouble2 = "src/main/assets/go_track_trackspoints_modified-4.csv";

        writeAllLines(recordsDateTimeChangedToDouble2, pathToFileWithDateTimeChangedToDouble2);

        myInput2 = new FileInputStream(pathToFileWithDateTimeChangedToDouble2);

        String data2 = IOUtils.toString(myInput2, (Charset) null);

        String[] lines2 = data2.split("\n");

        //Create directories
        baseDir.mkdir();
        baseTrainDir.mkdir();
        featuresDirTrain.mkdir();
        labelsDirTrain.mkdir();
        baseTestDir.mkdir();
        featuresDirTest.mkdir();
        labelsDirTest.mkdir();

        int lineCount = 0;
        List<Pair<String, double[]>> contentAndLabels2 = new ArrayList<Pair<String, double[]>>();

        for (String line : lines2) {

            if(lineCount == 0)
            {
                lineCount++;
                continue;
            }

            String transposed = line.replaceAll(" +", "\n");

            String contentAndLabelsGeohashKeyString = "";
            for(int k = line.length() - 1; k > 0; --k)
            {
                if(line.charAt(k) != ',') {
                    contentAndLabelsGeohashKeyString = line.charAt(k) + contentAndLabelsGeohashKeyString;
                }
                else {
                    break;
                }
            }

            String comma = ",";
            int commaLastIndex = transposed.lastIndexOf(comma);
            String temp = transposed.substring(0, commaLastIndex);
            commaLastIndex = temp.lastIndexOf(comma);
            String temp2 = transposed.substring(0, commaLastIndex);
            String temp3 = temp2.substring(temp2.indexOf(comma) +1);
            transposed = "";
            transposed = temp;
            temp = "";

            String latitudeString = "";
            String longitudeString = "";
            for(int v = 0 ; v < line.length(); ++v)
            {
                if(line.charAt(v) != ',')
                {
                    latitudeString = latitudeString + line.charAt(v);
                }
                else {
                    line = line.substring(line.indexOf(",") + 1);
                    for (int w = 0; w < line.length(); ++w)
                    {
                        if (line.charAt(w) != ',') {
                            longitudeString = longitudeString + line.charAt(w);
                        } else {
                            break;
                        }
                    }
                    break;
                }

            }

            double LatitudeStringToDouble = Double.parseDouble(latitudeString);
            double LongitudeStringToDouble = Double.parseDouble(longitudeString);


            double lines2LatitudeLongitudeHolder[] = {LatitudeStringToDouble, LongitudeStringToDouble};
            contentAndLabels2.add(new Pair<>(transposed, lines2LatitudeLongitudeHolder));
        }


        contentAndLabels2Size = contentAndLabels2.size();
        System.out.println("contentAndLabels2Size - "+contentAndLabels2Size);

        int contentAndLabels2RecordCount = 0;
        for(Pair contentAndLabels2Record : contentAndLabels2)
        {
            contentAndLabels2RecordCount++;
            if(contentAndLabels2RecordCount > 1000)
            {
                break;
            }
        }

        nItemsInDataSet = contentAndLabels2Size;   //75% train, 25% test
        nTrain = (int)Math.round(nItemsInDataSet * .75);
        nTest = nItemsInDataSet - nTrain;
        int trainCount = 0;
        int testCount = 0;

        System.out.println("nTrain - "+nTrain);

        double[] labelHolder2 = contentAndLabels2.get(0).getSecond();

        String featureAllBelongingToOneLabelHolder2 = "";
        String featureHolderSingle2 = contentAndLabels2.get(0).getFirst();
        int featureHolderIndex2 = 0;
        int featureRecordIndexLocal = 0;
        ArrayList<double[]>  latitudeLongitudeOfRecordsWithTheSameGeohash = new ArrayList<double[]>();

        System.out.println("labelHolder2 - "+labelHolder2);
        System.out.println("featureHolderSingle2 - "+featureHolderSingle2);

        for (Pair<String, double[]> p : contentAndLabels2) {
            //Write output in a format we can read, in the appropriate locations
            File outPathFeatures;
            File outPathLabels;

            if (featureHolderIndex2 < nTrain) {
                Long locationBeingCompared = LocationNextNeuralNetworkDL4J.GeoHashUtils.encodeAsLong(labelHolder2[0], labelHolder2[1], 8);
                Long locationToCompareToGeohash = LocationNextNeuralNetworkDL4J.GeoHashUtils.encodeAsLong(p.getSecond()[0], p.getSecond()[1], 8);
                if(String.valueOf(locationBeingCompared).equals(String.valueOf(locationToCompareToGeohash)))
                {
                    if(featureAllBelongingToOneLabelHolder2.equalsIgnoreCase(""))
                    {
                        featureAllBelongingToOneLabelHolder2 = p.getFirst();
                        ++featureRecordIndexLocal;
                        latitudeLongitudeOfRecordsWithTheSameGeohash.add(new double[]{p.getSecond()[0], p.getSecond()[1]});
                        String firstFeatureFileRecord = p.getFirst();
                        Log.info(" - firstFeatureFileRecord - 0 - "+firstFeatureFileRecord);
                    }
                    else
                    {
                        Log.info(" - featureRecordIndexLocal - "+featureRecordIndexLocal);
                        featureAllBelongingToOneLabelHolder2 = featureAllBelongingToOneLabelHolder2 + "\n" + p.getFirst();
                        ++featureRecordIndexLocal;
                        latitudeLongitudeOfRecordsWithTheSameGeohash.add(new double[]{p.getSecond()[0], p.getSecond()[1]});
                    }
                    featureHolderIndex2++;
                    continue;
                }
                else
                {
                    lastTrainCount = trainCount;
                    if(featureAllBelongingToOneLabelHolder2.equalsIgnoreCase(""))
                    {
                        featureAllBelongingToOneLabelHolder2 = contentAndLabels2.get(featureHolderIndex2 - 1).getFirst();

                        String firstFeatureFileRecord = contentAndLabels2.get(featureHolderIndex2 - 1).getFirst();
                    }

                    outPathFeatures = new File(featuresDirTrain, trainCount + ".csv");
                    outPathLabels = new File(labelsDirTrain, trainCount + ".csv");
                    trainCount++;
                    FileUtils.writeStringToFile(outPathFeatures, featureAllBelongingToOneLabelHolder2, (Charset) null);

                    if(featureRecordIndexLocal > 1)
                    {
                        double labelLat = LocationNextNeuralNetworkDL4J.GeoHashUtils.decode(LocationNextNeuralNetworkDL4J.GeoHashUtils.encodeAsLong(labelHolder2[0], labelHolder2[1], 8)).getLat();
                        double labelLon = LocationNextNeuralNetworkDL4J.GeoHashUtils.decode(LocationNextNeuralNetworkDL4J.GeoHashUtils.encodeAsLong(labelHolder2[0], labelHolder2[1], 8)).getLon();

                        double[] latitudeOfRecordsWithTheSameGeohashArray = new double[latitudeLongitudeOfRecordsWithTheSameGeohash.size()];
                        double[] longitudeOfRecordsWithTheSameGeohashArray = new double[latitudeLongitudeOfRecordsWithTheSameGeohash.size()];
                        for(int t = 0; t < latitudeLongitudeOfRecordsWithTheSameGeohash.size(); ++t)
                        {
                            latitudeOfRecordsWithTheSameGeohashArray[t] = latitudeLongitudeOfRecordsWithTheSameGeohash.get(t)[0];
                            longitudeOfRecordsWithTheSameGeohashArray[t] = latitudeLongitudeOfRecordsWithTheSameGeohash.get(t)[1];
                        }
                        double meanLatitudeOfRecordsWithTheSameGeohash = StatUtils.mean(latitudeOfRecordsWithTheSameGeohashArray);
                        double meanLongitudeOfRecordsWithTheSameGeohash = StatUtils.mean(longitudeOfRecordsWithTheSameGeohashArray);
                        double medianLatitudeOfRecordsWithTheSameGeohash = StatUtils.percentile(latitudeOfRecordsWithTheSameGeohashArray, 0.50);
                        double medianLongitudeOfRecordsWithTheSameGeohash = StatUtils.percentile(longitudeOfRecordsWithTheSameGeohashArray, 0.50);

                        latitudeLongitudeOfRecordsWithTheSameGeohash = new ArrayList<double[]>();

                        FileUtils.writeStringToFile(outPathLabels, labelLat+","+labelLon, (Charset) null);
                        featureRecordIndexLocal = 0;
                    }
                    else
                    {
                        featureRecordIndexLocal = 0;
                        FileUtils.writeStringToFile(outPathLabels, contentAndLabels2.get(featureHolderIndex2 - 1).getSecond()[0]+","+contentAndLabels2.get(featureHolderIndex2 - 1).getSecond()[1], (Charset) null);
//                    FileUtils.writeStringToFile(outPathLabels, labelHolder2[0]+","+labelHolder2[1], (Charset) null);
                    }

                    if(featureHolderIndex2 == nTrain - 1)
                    {

                        FileUtils.writeStringToFile(outPathFeatures, contentAndLabels2.get(featureHolderIndex2).getFirst(), (Charset) null);
                        FileUtils.writeStringToFile(outPathLabels, contentAndLabels2.get(featureHolderIndex2).getSecond()[0]+","+contentAndLabels2.get(featureHolderIndex2).getSecond()[1], (Charset) null);

                    }
                    labelHolder2 = p.getSecond();
                    featureAllBelongingToOneLabelHolder2 = "";
                    featureHolderIndex2++;
                    featureRecordIndexLocal = 0;

                }

            }
            else
            {
                Long locationBeingCompared = LocationNextNeuralNetworkDL4J.GeoHashUtils.encodeAsLong(labelHolder2[0], labelHolder2[1], 8);
                Long locationToCompareToGeohash = LocationNextNeuralNetworkDL4J.GeoHashUtils.encodeAsLong(p.getSecond()[0], p.getSecond()[1], 8);
                if(String.valueOf(locationBeingCompared).equals(String.valueOf(locationToCompareToGeohash)))
                {
                    if(featureAllBelongingToOneLabelHolder2.equalsIgnoreCase(""))
                    {
                        featureAllBelongingToOneLabelHolder2 = p.getFirst();
                        ++featureRecordIndexLocal;
                        latitudeLongitudeOfRecordsWithTheSameGeohash.add(new double[]{p.getSecond()[0], p.getSecond()[1]});
                        String firstFeatureFileRecord = p.getFirst();

                        String firstFeatureFileRecord2 = contentAndLabels2.get(featureHolderIndex2 - 1).getFirst();

                    }
                    else
                    {
                        featureAllBelongingToOneLabelHolder2 = featureAllBelongingToOneLabelHolder2 + "\n" + p.getFirst();
                        ++featureRecordIndexLocal;
                        latitudeLongitudeOfRecordsWithTheSameGeohash.add(new double[]{p.getSecond()[0], p.getSecond()[1]});
                    }

                    featureHolderIndex2++;
                    continue;
                }
                else
                {
                    lastTestCount = testCount;
                    if(featureAllBelongingToOneLabelHolder2.equalsIgnoreCase(""))
                    {
                        featureAllBelongingToOneLabelHolder2 = contentAndLabels2.get(featureHolderIndex2 - 1).getFirst();

                        String firstFeatureFileRecord = contentAndLabels2.get(featureHolderIndex2 - 1).getFirst();
                    }
                    outPathFeatures = new File(featuresDirTest, testCount + ".csv");
                    outPathLabels = new File(labelsDirTest, testCount + ".csv");
                    testCount++;

                    if(featureRecordIndexLocal > 1)
                    {
                        double labelLat = LocationNextNeuralNetworkDL4J.GeoHashUtils.decode(LocationNextNeuralNetworkDL4J.GeoHashUtils.encodeAsLong(labelHolder2[0], labelHolder2[1], 8)).getLat();
                        double labelLon = LocationNextNeuralNetworkDL4J.GeoHashUtils.decode(LocationNextNeuralNetworkDL4J.GeoHashUtils.encodeAsLong(labelHolder2[0], labelHolder2[1], 8)).getLon();
                        Log.info(" - labelLat - 1 - "+labelLat);
                        Log.info(" - labelLon - 1 - "+labelLon);

                        double[] latitudeOfRecordsWithTheSameGeohashArray = new double[latitudeLongitudeOfRecordsWithTheSameGeohash.size()];
                        double[] longitudeOfRecordsWithTheSameGeohashArray = new double[latitudeLongitudeOfRecordsWithTheSameGeohash.size()];
                        for(int t = 0; t < latitudeLongitudeOfRecordsWithTheSameGeohash.size(); ++t)
                        {
                            latitudeOfRecordsWithTheSameGeohashArray[t] = latitudeLongitudeOfRecordsWithTheSameGeohash.get(t)[0];
                            longitudeOfRecordsWithTheSameGeohashArray[t] = latitudeLongitudeOfRecordsWithTheSameGeohash.get(t)[1];
                        }
                        double meanLatitudeOfRecordsWithTheSameGeohash = StatUtils.mean(latitudeOfRecordsWithTheSameGeohashArray);
                        double meanLongitudeOfRecordsWithTheSameGeohash = StatUtils.mean(longitudeOfRecordsWithTheSameGeohashArray);
                        double medianLatitudeOfRecordsWithTheSameGeohash = StatUtils.percentile(latitudeOfRecordsWithTheSameGeohashArray, 0.50);
                        double medianLongitudeOfRecordsWithTheSameGeohash = StatUtils.percentile(longitudeOfRecordsWithTheSameGeohashArray, 0.50);

                        latitudeLongitudeOfRecordsWithTheSameGeohash = new ArrayList<double[]>();

                        FileUtils.writeStringToFile(outPathLabels, labelLat+","+labelLon, (Charset) null);
                        featureRecordIndexLocal = 0;
                    }
                    else
                    {
                        featureRecordIndexLocal = 0;
                        FileUtils.writeStringToFile(outPathLabels, contentAndLabels2.get(featureHolderIndex2 - 1).getSecond()[0]+","+contentAndLabels2.get(featureHolderIndex2 - 1).getSecond()[1], (Charset) null);
                    }

                    FileUtils.writeStringToFile(outPathFeatures, featureAllBelongingToOneLabelHolder2, (Charset) null);

                    if(featureHolderIndex2 == contentAndLabels2.size() - 1)
                    {
                        FileUtils.writeStringToFile(outPathFeatures, contentAndLabels2.get(featureHolderIndex2).getFirst(), (Charset) null);
                        FileUtils.writeStringToFile(outPathLabels, contentAndLabels2.get(featureHolderIndex2).getSecond()[0]+","+contentAndLabels2.get(featureHolderIndex2).getSecond()[1], (Charset) null);
                    }
                    labelHolder2 = p.getSecond();
                    featureAllBelongingToOneLabelHolder2 = "";
                    featureHolderIndex2++;
                    featureRecordIndexLocal = 0;
                }

            }

        }
    }

    public static List<String[]> readLineByLine(Path filePath) throws Exception {
        List<String[]> list = new ArrayList<>();
        try (Reader reader = Files.newBufferedReader(filePath)) {
            try (CSVReader csvReader = new CSVReader(reader)) {

                String[] lineIn;
                String[] lineOut;

                Double dateTimeConvertedToDouble = 0.0;

                int readRecordIndex = 0;

                while ((lineIn = csvReader.readNext()) != null) {

                    list.add(lineIn);

                    ++readRecordIndex;

                }
            }
        }

        return list;

    }

    public static List<String[]> readLineByLine2(Path filePath) throws Exception {
        List<String[]> list = new ArrayList<>();
        try (Reader reader = Files.newBufferedReader(filePath)) {
            try (CSVReader csvReader = new CSVReader(reader)) {

                String[] lineIn;
                String[] lineOut = new String[7];

                Double dateTimeConvertedToDouble = 0.0;

                int readRecordIndex = 0;

                while ((lineIn = csvReader.readNext()) != null) {


                    if(readRecordIndex == 0)
                    {
                        lineOut = new String[7];

                        lineOut[0] = "latitude";
                        lineOut[1] = "longitude";
                        lineOut[2] = "time";
                        lineOut[3] = "bearing";
                        lineOut[4] = "accuracy";
                        lineOut[5] = "macroMovementLocationChangeFlag";
                        lineOut[6] = "geohash";

                        list.add(lineOut);

                        ++readRecordIndex;

                        continue;

                    }



                    if(readRecordIndex > 0)
                    {

                        lineOut[0] = lineIn[0];
                        lineOut[1] = lineIn[1];
                        lineOut[2] = lineIn[2];

                        lineOut[3] = lineIn[3];

                        lineOut[4] = lineIn[4];
                        lineOut[5] = lineIn[5];

                        lineOut[6] = String.valueOf(LocationNextNeuralNetworkDL4J.GeoHashUtils.encodeAsLong(Double.parseDouble(lineIn[1]),Double.parseDouble(lineIn[2]), 8));

                    }

                    list.add(lineOut);

                    lineOut = new String[7];

                    ++readRecordIndex;

                }
            }

        }

        return list;

    }

    public static long convertDateTimeToSysTime(String sDateTime) {
        int nYear = Integer.parseInt(sDateTime.substring(0, 4));
        int nMonth = Integer.parseInt(sDateTime.substring(5, 7));
        int nDay = Integer.parseInt(sDateTime.substring(8, 10));
        int nHour = 0, nMinute = 0, nSecond = 0;
        if (sDateTime.length() >= 14) {
            nHour = Integer.parseInt(sDateTime.substring(10, 12));
            nMinute = Integer.parseInt(sDateTime.substring(13, 15));
            nSecond = Integer.parseInt(sDateTime.substring(17));
        }
        Calendar calendar = Calendar.getInstance();
        calendar.set(nYear, nMonth - 1, nDay, nHour, nMinute, nSecond);
        return calendar.getTime().getTime();
    }

    public static void writeAllLines(List<String[]> lines, String path) throws Exception {
        File fileWithDateTimeChangedToDouble = new File(path);
        try (CSVWriter writer = new CSVWriter(new FileWriter(fileWithDateTimeChangedToDouble), ',', CSVWriter.NO_QUOTE_CHARACTER)) {
            writer.writeAll(lines);
        }

    }

    private static XYSeriesCollection createSeries(XYSeriesCollection seriesCollection, INDArray data, int offset, String name) {
        int nRows = (int)data.shape()[2];
        XYSeries series = new XYSeries(name);
        for (int i = 0; i < nRows; i++) {
            series.add(i + offset, data.getDouble(i));
        }

        seriesCollection.addSeries(series);

        return seriesCollection;
    }

    /**
     * Generate an xy plot of the datasets provided.
     */
    private static void plotDataset(XYSeriesCollection c) {

        String title = "Regression example";
        String xAxisLabel = "Timestep";
        String yAxisLabel = "Number of passengers";
        PlotOrientation orientation = PlotOrientation.VERTICAL;
        boolean legend = true;
        boolean tooltips = false;
        boolean urls = false;
        JFreeChart chart = ChartFactory.createXYLineChart(title, xAxisLabel, yAxisLabel, c, orientation, legend, tooltips, urls);

        // get a reference to the plot for further customisation...
        final XYPlot plot = chart.getXYPlot();

        // Auto zoom to fit time series in initial window
        final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setAutoRange(true);

        JPanel panel = new ChartPanel(chart);

        JFrame f = new JFrame();
        f.add(panel);
        f.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        f.pack();
        f.setTitle("Training Data");

        RefineryUtilities.centerFrameOnScreen(f);
        f.setVisible(true);
    }

    /**
     * Licensed to the Apache Software Foundation (ASF) under one or more
     * contributor license agreements.  See the NOTICE file distributed with
     * this work for additional information regarding copyright ownership.
     * The ASF licenses this file to You under the Apache License, Version 2.0
     * (the "License"); you may not use this file except in compliance with
     * the License.  You may obtain a copy of the License at
     *
     *     http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */

    /**
     * Utilities for encoding and decoding geohashes. Based on
     * http://en.wikipedia.org/wiki/Geohash.
     */
    // LUCENE MONITOR: monitor against spatial package
    // replaced with native DECODE_MAP
    public static class GeoHashUtils {

        private static final char[] BASE_32 = {'0', '1', '2', '3', '4', '5', '6',
                '7', '8', '9', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'm', 'n',
                'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};

        public static final int PRECISION = 12;
        private static final int[] BITS = {16, 8, 4, 2, 1};

        private GeoHashUtils() {
        }

        public static String encode(double latitude, double longitude) {
            return encode(latitude, longitude, PRECISION);
        }

        /**
         * Encodes the given latitude and longitude into a geohash
         *
         * @param latitude  Latitude to encode
         * @param longitude Longitude to encode
         * @return Geohash encoding of the longitude and latitude
         */
        public static String encode(double latitude, double longitude, int precision) {
            //        double[] latInterval = {-90.0, 90.0};
            //        double[] lngInterval = {-180.0, 180.0};
            double latInterval0 = -90.0;
            double latInterval1 = 90.0;
            double lngInterval0 = -180.0;
            double lngInterval1 = 180.0;

            final StringBuilder geohash = new StringBuilder();
            boolean isEven = true;

            int bit = 0;
            int ch = 0;

            while (geohash.length() < precision) {
                double mid = 0.0;
                if (isEven) {
                    //                mid = (lngInterval[0] + lngInterval[1]) / 2D;
                    mid = (lngInterval0 + lngInterval1) / 2D;
                    if (longitude > mid) {
                        ch |= BITS[bit];
                        //                    lngInterval[0] = mid;
                        lngInterval0 = mid;
                    } else {
                        //                    lngInterval[1] = mid;
                        lngInterval1 = mid;
                    }
                } else {
                    //                mid = (latInterval[0] + latInterval[1]) / 2D;
                    mid = (latInterval0 + latInterval1) / 2D;
                    if (latitude > mid) {
                        ch |= BITS[bit];
                        //                    latInterval[0] = mid;
                        latInterval0 = mid;
                    } else {
                        //                    latInterval[1] = mid;
                        latInterval1 = mid;
                    }
                }

                isEven = !isEven;

                if (bit < 4) {
                    bit++;
                } else {
                    geohash.append(BASE_32[ch]);
                    bit = 0;
                    ch = 0;
                }
            }

            return geohash.toString();
        }

        private static final char encode(int x, int y) {
            return BASE_32[((x & 1) + ((y & 1) * 2) + ((x & 2) * 2) + ((y & 2) * 4) + ((x & 4) * 4)) % 32];
        }

        /**
         * Calculate all neighbors of a given geohash cell.
         *
         * @param geohash Geohash of the defined cell
         * @return geohashes of all neighbor cells
         */
        public static Collection<? extends CharSequence> neighbors(String geohash) {
            return addNeighbors(geohash, geohash.length(), new ArrayList<CharSequence>(8));
        }

        /**
         * Calculate the geohash of a neighbor of a geohash
         *
         * @param geohash the geohash of a cell
         * @param level   level of the geohash
         * @param dx      delta of the first grid coordinate (must be -1, 0 or +1)
         * @param dy      delta of the second grid coordinate (must be -1, 0 or +1)
         * @return geohash of the defined cell
         */
        private final static String neighbor(String geohash, int level, int dx, int dy) {
            int cell = decode(geohash.charAt(level - 1));

            // Decoding the Geohash bit pattern to determine grid coordinates
            int x0 = cell & 1;  // first bit of x
            int y0 = cell & 2;  // first bit of y
            int x1 = cell & 4;  // second bit of x
            int y1 = cell & 8;  // second bit of y
            int x2 = cell & 16; // third bit of x

            // combine the bitpattern to grid coordinates.
            // note that the semantics of x and y are swapping
            // on each level
            int x = x0 + (x1 / 2) + (x2 / 4);
            int y = (y0 / 2) + (y1 / 4);

            if (level == 1) {
                // Root cells at north (namely "bcfguvyz") or at
                // south (namely "0145hjnp") do not have neighbors
                // in north/south direction
                if ((dy < 0 && y == 0) || (dy > 0 && y == 3)) {
                    return null;
                } else {
                    return Character.toString(encode(x + dx, y + dy));
                }
            } else {
                // define grid coordinates for next level
                final int nx = ((level % 2) == 1) ? (x + dx) : (x + dy);
                final int ny = ((level % 2) == 1) ? (y + dy) : (y + dx);

                // if the defined neighbor has the same parent a the current cell
                // encode the cell directly. Otherwise find the cell next to this
                // cell recursively. Since encoding wraps around within a cell
                // it can be encoded here.
                // xLimit and YLimit must always be respectively 7 and 3
                // since x and y semantics are swapping on each level.
                if (nx >= 0 && nx <= 7 && ny >= 0 && ny <= 3) {
                    return geohash.substring(0, level - 1) + encode(nx, ny);
                } else {
                    String neighbor = neighbor(geohash, level - 1, dx, dy);
                    if(neighbor != null) {
                        return neighbor + encode(nx, ny);
                    } else {
                        return null;
                    }
                }
            }
        }

        /**
         * Add all geohashes of the cells next to a given geohash to a list.
         *
         * @param geohash   Geohash of a specified cell
         * @param neighbors list to add the neighbors to
         * @return the given list
         */
        public static final <E extends Collection<? super String>> E addNeighbors(String geohash, E neighbors) {
            return addNeighbors(geohash, geohash.length(), neighbors);
        }

        /**
         * Add all geohashes of the cells next to a given geohash to a list.
         *
         * @param geohash   Geohash of a specified cell
         * @param length    level of the given geohash
         * @param neighbors list to add the neighbors to
         * @return the given list
         */
        public static final <E extends Collection<? super String>> E addNeighbors(String geohash, int length, E neighbors) {
            String south = neighbor(geohash, length, 0, -1);
            String north = neighbor(geohash, length, 0, +1);
            if (north != null) {
                neighbors.add(neighbor(north, length, -1, 0));
                neighbors.add(north);
                neighbors.add(neighbor(north, length, +1, 0));
            }

            neighbors.add(neighbor(geohash, length, -1, 0));
            neighbors.add(neighbor(geohash, length, +1, 0));

            if (south != null) {
                neighbors.add(neighbor(south, length, -1, 0));
                neighbors.add(south);
                neighbors.add(neighbor(south, length, +1, 0));
            }

            return neighbors;
        }

        private static final int decode(char geo) {
            switch (geo) {
                case '0':
                    return 0;
                case '1':
                    return 1;
                case '2':
                    return 2;
                case '3':
                    return 3;
                case '4':
                    return 4;
                case '5':
                    return 5;
                case '6':
                    return 6;
                case '7':
                    return 7;
                case '8':
                    return 8;
                case '9':
                    return 9;
                case 'b':
                    return 10;
                case 'c':
                    return 11;
                case 'd':
                    return 12;
                case 'e':
                    return 13;
                case 'f':
                    return 14;
                case 'g':
                    return 15;
                case 'h':
                    return 16;
                case 'j':
                    return 17;
                case 'k':
                    return 18;
                case 'm':
                    return 19;
                case 'n':
                    return 20;
                case 'p':
                    return 21;
                case 'q':
                    return 22;
                case 'r':
                    return 23;
                case 's':
                    return 24;
                case 't':
                    return 25;
                case 'u':
                    return 26;
                case 'v':
                    return 27;
                case 'w':
                    return 28;
                case 'x':
                    return 29;
                case 'y':
                    return 30;
                case 'z':
                    return 31;
                default:
                    throw new IllegalArgumentException("the character '" + geo + "' is not a valid geohash character");
            }
        }

        /**
         * Decodes the given geohash
         *
         * @param geohash Geohash to decocde
         * @return {@link GeoPoint} at the center of cell, given by the geohash
         */
        public static GeoPoint decode(String geohash) {
            return decode(geohash, new GeoPoint());
        }

        /**
         * Decodes the given geohash into a latitude and longitude
         *
         * @param geohash Geohash to decocde
         * @return the given {@link GeoPoint} reseted to the center of
         *         cell, given by the geohash
         */
        public static GeoPoint decode(String geohash, GeoPoint ret) {
            double[] interval = decodeCell(geohash);
            return ret.reset((interval[0] + interval[1]) / 2D, (interval[2] + interval[3]) / 2D);
        }

        private static double[] decodeCell(String geohash) {
            double[] interval = {-90.0, 90.0, -180.0, 180.0};
            boolean isEven = true;

            for (int i = 0; i < geohash.length(); i++) {
                final int cd = decode(geohash.charAt(i));

                for (int mask : BITS) {
                    if (isEven) {
                        if ((cd & mask) != 0) {
                            interval[2] = (interval[2] + interval[3]) / 2D;
                        } else {
                            interval[3] = (interval[2] + interval[3]) / 2D;
                        }
                    } else {
                        if ((cd & mask) != 0) {
                            interval[0] = (interval[0] + interval[1]) / 2D;
                        } else {
                            interval[1] = (interval[0] + interval[1]) / 2D;
                        }
                    }
                    isEven = !isEven;
                }
            }
            return interval;
        }

        //========== long-based encodings for geohashes ========================================


        /**
         * Encodes latitude and longitude information into a single long with variable precision.
         * Up to 12 levels of precision are supported which should offer sub-metre resolution.
         *
         * @param latitude
         * @param longitude
         * @param precision The required precision between 1 and 12
         * @return A single long where 4 bits are used for holding the precision and the remaining
         * 60 bits are reserved for 5 bit cell identifiers giving up to 12 layers.
         */
        public static long encodeAsLong(double latitude, double longitude, int precision) {
            if((precision>12)||(precision<1))
            {
                throw new IllegalArgumentException("Illegal precision length of "+precision+
                        ". Long-based geohashes only support precisions between 1 and 12");
            }
            double latInterval0 = -90.0;
            double latInterval1 = 90.0;
            double lngInterval0 = -180.0;
            double lngInterval1 = 180.0;

            long geohash = 0l;
            boolean isEven = true;

            int bit = 0;
            int ch = 0;

            int geohashLength=0;
            while (geohashLength < precision) {
                double mid = 0.0;
                if (isEven) {
                    mid = (lngInterval0 + lngInterval1) / 2D;
                    if (longitude > mid) {
                        ch |= BITS[bit];
                        lngInterval0 = mid;
                    } else {
                        lngInterval1 = mid;
                    }
                } else {
                    mid = (latInterval0 + latInterval1) / 2D;
                    if (latitude > mid) {
                        ch |= BITS[bit];
                        latInterval0 = mid;
                    } else {
                        latInterval1 = mid;
                    }
                }

                isEven = !isEven;

                if (bit < 4) {
                    bit++;
                } else {
                    geohashLength++;
                    geohash|=ch;
                    if(geohashLength<precision){
                        geohash<<=5;
                    }
                    bit = 0;
                    ch = 0;
                }
            }
            geohash<<=4;
            geohash|=precision;
            return geohash;
        }

        /**
         * Formats a geohash held as a long as a more conventional
         * String-based geohash
         * @param geohashAsLong a geohash encoded as a long
         * @return A traditional base32-based String representation of a geohash
         */
        public static String toString(long geohashAsLong)
        {
            int precision = (int) (geohashAsLong&15);
            char[] chars = new char[precision];
            geohashAsLong >>= 4;
            for (int i = precision - 1; i >= 0 ; i--) {
                chars[i] =  BASE_32[(int) (geohashAsLong & 31)];
                geohashAsLong >>= 5;
            }
            return new String(chars);
        }



        public static GeoPoint decode(long geohash) {
            GeoPoint point = new GeoPoint();
            decode(geohash, point);
            return point;
        }

        /**
         * Decodes the given long-format geohash into a latitude and longitude
         *
         * @param geohash long format Geohash to decode
         * @param ret The Geopoint into which the latitude and longitude will be stored
         */
        public static void decode(long geohash, GeoPoint ret) {
            double[] interval = decodeCell(geohash);
            ret.reset((interval[0] + interval[1]) / 2D, (interval[2] + interval[3]) / 2D);

        }

        private static double[] decodeCell(long geohash) {
            double[] interval = {-90.0, 90.0, -180.0, 180.0};
            boolean isEven = true;

            int precision= (int) (geohash&15);
            geohash>>=4;
            int[]cds=new int[precision];
            for (int i = precision-1; i >=0 ; i--) {
                cds[i] = (int) (geohash&31);
                geohash>>=5;
            }

            for (int i = 0; i <cds.length ; i++) {
                final int cd = cds[i];
                for (int mask : BITS) {
                    if (isEven) {
                        if ((cd & mask) != 0) {
                            interval[2] = (interval[2] + interval[3]) / 2D;
                        } else {
                            interval[3] = (interval[2] + interval[3]) / 2D;
                        }
                    } else {
                        if ((cd & mask) != 0) {
                            interval[0] = (interval[0] + interval[1]) / 2D;
                        } else {
                            interval[1] = (interval[0] + interval[1]) / 2D;
                        }
                    }
                    isEven = !isEven;
                }
            }
            return interval;
        }
    }

    /*
     * Licensed to Elasticsearch under one or more contributor
     * license agreements. See the NOTICE file distributed with
     * this work for additional information regarding copyright
     * ownership. Elasticsearch licenses this file to you under
     * the Apache License, Version 2.0 (the "License"); you may
     * not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *    http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing,
     * software distributed under the License is distributed on an
     * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
     * KIND, either express or implied.  See the License for the
     * specific language governing permissions and limitations
     * under the License.
     */

    /**
     *
     */
    public static class GeoPoint {

        private double lat;
        private double lon;

        public GeoPoint() {
        }

        /**
         * Create a new Geopointform a string. This String must either be a geohash
         * or a lat-lon tuple.
         *
         * @param value String to create the point from
         */
        public GeoPoint(String value) {
            this.resetFromString(value);
        }

        public GeoPoint(double lat, double lon) {
            this.lat = lat;
            this.lon = lon;
        }

        public GeoPoint reset(double lat, double lon) {
            this.lat = lat;
            this.lon = lon;
            return this;
        }

        public GeoPoint resetLat(double lat) {
            this.lat = lat;
            return this;
        }

        public GeoPoint resetLon(double lon) {
            this.lon = lon;
            return this;
        }

        public GeoPoint resetFromString(String value) {
            int comma = value.indexOf(',');
            if (comma != -1) {
                lat = Double.parseDouble(value.substring(0, comma).trim());
                lon = Double.parseDouble(value.substring(comma + 1).trim());
            } else {
                resetFromGeoHash(value);
            }
            return this;
        }

        public GeoPoint resetFromGeoHash(String hash) {
            GeoHashUtils.decode(hash, this);
            return this;
        }

        public final double lat() {
            return this.lat;
        }

        public final double getLat() {
            return this.lat;
        }

        public final double lon() {
            return this.lon;
        }

        public final double getLon() {
            return this.lon;
        }

        public final String geohash() {
            return GeoHashUtils.encode(lat, lon);
        }

        public final String getGeohash() {
            return GeoHashUtils.encode(lat, lon);
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            GeoPoint geoPoint = (GeoPoint) o;

            if (Double.compare(geoPoint.lat, lat) != 0) return false;
            if (Double.compare(geoPoint.lon, lon) != 0) return false;

            return true;
        }

        @Override
        public int hashCode() {
            int result;
            long temp;
            temp = lat != +0.0d ? Double.doubleToLongBits(lat) : 0L;
            result = (int) (temp ^ (temp >>> 32));
            temp = lon != +0.0d ? Double.doubleToLongBits(lon) : 0L;
            result = 31 * result + (int) (temp ^ (temp >>> 32));
            return result;
        }

        @Override
        public String toString() {
            return "[" + lat + ", " + lon + "]";
        }

        public static GeoPoint parseFromLatLon(String latLon) {
            GeoPoint point = new GeoPoint();
            point.resetFromString(latLon);
            return point;
        }
    }

}
